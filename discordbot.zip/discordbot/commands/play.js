module.exports.run = async(bot,message,args,ops) =>{
    var Discord = require('discord.js');
    var GetID = message.author.id;
    var prefix = '!';
    var ffmpeg = require("ffmpeg")
    var opus = require("opusscript")
    var ytdl = require("ytdl-core")
    var cont = message.content.slice(prefix.length).split(" ");
    var args = cont.slice(1);
    let info = await ytdl.getInfo(args[0])
    if (args[0] == null) return message.channel.send("no song link")
    let data = ops.active.get(message.guild.id) || {}
    if (!data.connection) data.connection = await message.member.voiceChannel.join()
    if (!data.queue) data.queue = []
    data.guildID = message.guild.id
    data.queue.push({
        songTitle: info.title,
        requester: message.author.tag,
        url: args[0],
    })
    if (!data.dispatcherplay) play(bot,ops,data)
    else{
        message.channel.send(`Added to queue: ${info.title}, Requested by: <@${message.author.id}>`)
    }
    ops.active.set(message.guild.id,data)
    async function play(bot,ops,data){
        message.channel.send(`Now playing: ${data.queue[0].songTitle}`)
        data.dispatcher = await data.connection.playStream(ytdl(data.queue[0].url))
        data.dispatcher.setVolume(0.05)
        data.dispatcher.guildID = data.guildID
        data.dispatcher.once("end",function(){
            finish(bot,ops,this)    
        })
    }
    function finish(bot,ops,dispatcher){
        let fetched = ops.active.get(dispatcher.guildID)
        fetched.queue.shift()
        if (fetched.queue.length > 0){
            ops.active.set(dispatcher.guildID,fetched)
            play(bot,ops,fetched)
        }else{
            ops.active.delete(dispatcher.guildID)
            let vc = bot.guilds.get(dispatcher.guildID).me.voiceChannel
            if (vc) vc.leave()
        }
    }
}
module.exports.help = {
    name: "play"
}