module.exports.run = async(bot,message,args,ops) =>{
    let fetched = ops.active.get(message.guild.id)
    fetched.dispatcher.setVolume(args[0]/100)

}
module.exports.help = {
    name:"volume"
}