module.exports.run = async (bot, message, args) => {
	var Discord = require('discord.js');
	var GetID = message.author.id;
	var prefix = '!';
	var cont = message.content.slice(prefix.length).split(" ");
	var args = cont.slice(1);
	var sender = message.author;
	var msg = message.content.toUpperCase();
			if(args[0] == null) return message.channel.send('Enter a number!')
			if (isNaN(args[0])) return message.channel.send("Invalid Number!")
		async function purge() {
			message.delete();
			var gotem = await message.channel.fetchMessages({limit: args[0]});
			message.channel.bulkDelete(gotem)
			message.channel.send('I cleared ' +(args[0]) + ' messages! Command done by: ' + sender)
		}
		purge();
//Dont touch this
}

module.exports.help = {
		name: "purge" //Command
}