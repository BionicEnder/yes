module.exports.run = async(bot,message,args,ops) =>{
    
}
module.exports.help = {
    name:"loop"
}