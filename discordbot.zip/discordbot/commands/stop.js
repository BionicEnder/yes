module.exports.run = async(bot,message,args,ops) =>{
    var Discord = require('discord.js');
    var GetID = message.author.id;
    var prefix = '!';
    var ffmpeg = require("ffmpeg")
    var opus = require("opusscript")
    var ytdl = require("ytdl-core")
    var cont = message.content.slice(prefix.length).split(" ");
    var args = cont.slice(1);
    var sender = message.author;
    var msg = message.content.toUpperCase();
    var song = args.slice(0).join(" ")
    var vc = message.member.voiceChannel
    if (vc == null) return message.channel.send("not in a vc")
    vc.leave()
    
}
module.exports.help = {
    name: "stop"
}