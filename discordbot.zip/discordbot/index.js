require('dotenv').config();
var Discord = require('discord.js');
var bot = new Discord.Client();
var TOKEN = process.env.TOKEN;
var prefix = '!';
//const fs = require('fs')
const fs = require('fs-extra');
bot.commands = new Discord.Collection()
const active = new Map()

fs.readdir("commands/", (err, files) => { 
	if(err) console.log(err);
	
	let jsfile = files.filter(f => f.split(".").pop() === "js")
	if(jsfile.length <= 0){ 
		console.log("Could not find commands!");
		return;
	}
	jsfile.forEach((f, i) =>{ 
		let props = require(`./commands/${f}`);
		console.log(`${f} loaded!`)
		bot.commands.set(props.help.name, props);
	});
});

bot.on('message', async message => {
	let prefix = "!";
	let messageArray = message.content.split(" ");
	let cmd = messageArray[0];
	let args = messageArray.slice(1);
	let ops = {
		active: active
	}
	let commandfile = bot.commands.get(cmd.slice(prefix.length));
	if(commandfile) commandfile.run(bot,message,args,ops);
});


bot.login(TOKEN);